%����pֵ
clc;clear all
data=load('yeast_gene_data.txt');
p=zeros(1,8)
h=[]
for i =1:8
[H1,P,LSTAT,CV] = lillietest(data(i,:));
p(1,i)=P
h(1,i)=H1
end